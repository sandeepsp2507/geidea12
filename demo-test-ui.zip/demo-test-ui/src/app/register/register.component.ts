import { Component, OnInit } from '@angular/core';
import {  FormControl, FormGroup, Validators } from '@angular/forms';
import { RegisterService } from '../register.service';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
  providers:[RegisterService]
})
export class RegisterComponent implements OnInit {

  registerForm: FormGroup;
  loyalty:any = ["STC","SABB"]
  selectedLoyalty:any = "STC"
  register$;
  cities:any
  isEditMode:boolean = false
  arabicString: string
  registerFormData:any;

  constructor(private service:RegisterService) { 

    this.registerForm = new FormGroup({
      terminalId: new FormControl('', [Validators.required,Validators.maxLength(255)]),
      merchantNameEn: new FormControl('', [Validators.required,Validators.maxLength(255)]),
      merchantNameAr: new FormControl(null,[Validators.required]),
      merchantAddrEn: new FormControl(null,[Validators.required]),
      merchantAddrAr: new FormControl(null,[Validators.required]),
      branchId: new FormControl(null),
      userId: new FormControl(null),
      city: new FormControl(null,[Validators.required]),
      cityId: new FormControl(null,[Validators.required]),
      cityNameEn: new FormControl(null,[Validators.required]),
      cityNameAr: new FormControl(null,[Validators.required]),
    })
  }

  ngOnInit(): void {
    this.getAllCities()
  }


  changeLoyalty(event){
    this.selectedLoyalty = event
  }

  changeCity(event){
    this.registerForm.patchValue({city:event})
  }

  getAllCities(){
    this.register$ = this.service.getAllCities().subscribe(data=>{
      let response = <any>data
      let responseDataMap = []
      responseDataMap =  response.data
      responseDataMap.map(element=>{
        if(element.country == 'India'){
          this.cities = element.cities
        }
      })
    })
  }

  register(){
    this.registerForm.value
  }


  clearForm(){
    this.registerForm.reset()
  }

  editMode(){
    this.isEditMode = !this.isEditMode
  }

  searchTerminal(id){
    console.log(id)
    // let response = <any>data

    this.registerForm.patchValue({
      terminalId: this.registerFormData.terminalId,
      merchantNameEn: this.registerFormData.merchantNameEn,
      merchantNameAr: this.registerFormData.merchantNameAr,
      merchantAddrEn: this.registerFormData.merchantAddrEn,
      merchantAddrAr: this.registerFormData.merchantAddrAr,
      branchId: this.registerFormData.branchId,
      userId: this.registerFormData.userId,
      city: this.registerFormData.city,
      cityId: this.registerFormData.cityId,
      cityNameEn: this.registerFormData.cityNameEn,
      cityNameAr: this.registerFormData.cityNameAr
    })
  }

  arabicValue(txt) {
    this.arabicString = null
    this.arabicString = txt;
    this.arabicString = this.arabicString.replace(/`/g, "ذ");
    this.arabicString = this.arabicString.replace(/0/g, "۰");
    this.arabicString = this.arabicString.replace(/1/g, "۱");
    this.arabicString = this.arabicString.replace(/2/g, "۲");
    this.arabicString = this.arabicString.replace(/3/g, "۳");
    this.arabicString = this.arabicString.replace(/4/g, "٤");
    this.arabicString = this.arabicString.replace(/5/g, "۵");
    this.arabicString = this.arabicString.replace(/6/g, "٦");
    this.arabicString = this.arabicString.replace(/7/g, "۷");
    this.arabicString = this.arabicString.replace(/8/g, "۸");
    this.arabicString = this.arabicString.replace(/9/g, "۹");
    this.arabicString = this.arabicString.replace(/0/g, "۰");
    this.arabicString  = this.arabicString.replace(/q/g, "ض");
    this.arabicString  = this.arabicString.replace(/w/g, "ص");
    this.arabicString  = this.arabicString.replace(/e/g, "ث");
    this.arabicString  = this.arabicString.replace(/r/g, "ق");
    this.arabicString  = this.arabicString.replace(/t/g, "ف"); 
    this.arabicString  = this.arabicString.replace(/y/g, "غ");
    this.arabicString  = this.arabicString.replace(/u/g, "ع");
    this.arabicString  = this.arabicString.replace(/i/g, "ه");
    this.arabicString  = this.arabicString.replace(/o/g, "خ");
    this.arabicString  = this.arabicString.replace(/p/g, "ح");
    this.arabicString  = this.arabicString.replace(/\[/g, "ج");
    this.arabicString  = this.arabicString.replace(/\]/g, "د");
    this.arabicString  = this.arabicString.replace(/a/g, "ش");
    this.arabicString  = this.arabicString.replace(/s/g, "س");
    this.arabicString  = this.arabicString.replace(/d/g, "ي");
    this.arabicString  = this.arabicString.replace(/f/g, "ب");
    this.arabicString  = this.arabicString.replace(/g/g, "ل");
    this.arabicString  = this.arabicString.replace(/h/g, "ا");
    this.arabicString  = this.arabicString.replace(/j/g, "ت");
    this.arabicString  = this.arabicString.replace(/k/g, "ن");
    this.arabicString  = this.arabicString.replace(/l/g, "م");
    this.arabicString = this.arabicString.replace(/\;/g, "ك");
    this.arabicString  = this.arabicString.replace(/\'/g, "ط");
    this.arabicString  = this.arabicString.replace(/z/g, "ئ");
    this.arabicString  = this.arabicString.replace(/x/g, "ء");
    this.arabicString  = this.arabicString.replace(/c/g, "ؤ");
    this.arabicString  = this.arabicString.replace(/v/g, "ر");
    this.arabicString  = this.arabicString.replace(/b/g, "لا");
    this.arabicString  = this.arabicString.replace(/n/g, "ى");
    this.arabicString  = this.arabicString.replace(/m/g, "ة");
    this.arabicString  = this.arabicString.replace(/\,/g, "و");
    this.arabicString  = this.arabicString.replace(/\./g, "ز");
    this.arabicString  = this.arabicString.replace(/\//g, "ظ");
    this.arabicString  = this.arabicString.replace(/~/g, " ّ");
    this.arabicString  = this.arabicString.replace(/Q/g, "َ");
    this.arabicString  = this.arabicString.replace(/W/g, "ً");
    this.arabicString  = this.arabicString.replace(/E/g, "ُ");
    this.arabicString  = this.arabicString.replace(/R/g, "ٌ");
    this.arabicString  = this.arabicString.replace(/T/g, "لإ");
    this.arabicString  = this.arabicString.replace(/Y/g, "إ");
    this.arabicString  = this.arabicString.replace(/U/g, "‘");
    this.arabicString  = this.arabicString.replace(/I/g, "÷");
    this.arabicString  = this.arabicString.replace(/O/g, "×");
    this.arabicString  = this.arabicString.replace(/P/g, "؛");
    this.arabicString  = this.arabicString.replace(/A/g, "ِ");
    this.arabicString  = this.arabicString.replace(/S/g, "ٍ");
    this.arabicString  = this.arabicString.replace(/G/g, "لأ");
    this.arabicString  = this.arabicString.replace(/H/g, "أ");
    this.arabicString  = this.arabicString.replace(/J/g, "ـ");
    this.arabicString  = this.arabicString.replace(/K/g, "،");
    this.arabicString  = this.arabicString.replace(/L/g, "/");
    this.arabicString  = this.arabicString.replace(/Z/g, "~");
    this.arabicString  = this.arabicString.replace(/X/g, "ْ");
    this.arabicString  = this.arabicString.replace(/B/g, "لآ");
    this.arabicString  = this.arabicString.replace(/N/g, "آ");
    this.arabicString  = this.arabicString.replace(/M/g, "’");
    this.arabicString  = this.arabicString.replace(/\?/g, "؟");
    return this.arabicString;
  }


  merchantNameArabic(text){
    let value = this.arabicValue(text)
    this.registerForm.patchValue({merchantNameAr:value})
  }

  merchantAddressArabic(text){
    let value = this.arabicValue(text)
    this.registerForm.patchValue({merchantAddrAr:value})
  }

  cityArabic(text){
    let value = this.arabicValue(text)
    this.registerForm.patchValue({cityNameAr:value})
  }

}
