import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable()
export class RegisterService {

  constructor(private http:HttpClient) { }

  getAllCities(){
    return this.http.get("https://countriesnow.space/api/v0.1/countries")
  }
}
